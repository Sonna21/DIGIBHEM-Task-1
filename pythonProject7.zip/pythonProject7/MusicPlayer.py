import os
import pygame
from tkinter import *
from tkinter import filedialog


class MusicPlayer:
    def __init__(self, root):
        self.root = root
        self.root.title("Music Player")
        self.root.geometry("300x100")


        pygame.init()


        self.isPlaying = False


        self.btn_select = Button(root, text="Select Song", command=self.select_song)
        self.btn_select.pack(pady=10)

        self.btn_play = Button(root, text="Play", state=DISABLED, command=self.play_song)
        self.btn_play.pack(pady=5)

        self.btn_pause = Button(root, text="Pause", state=DISABLED, command=self.pause_song)
        self.btn_pause.pack(pady=5)

        self.btn_stop = Button(root, text="Stop", state=DISABLED, command=self.stop_song)
        self.btn_stop.pack(pady=5)

        self.current_song_label = Label(root, text="No song selected")
        self.current_song_label.pack(pady=5)

    def select_song(self):
        song_path = filedialog.askopenfilename(filetypes=[("MP3 Files", "*.mp3")])

        if song_path:
            pygame.mixer.music.load(song_path)
            self.current_song_label["text"] = os.path.basename(song_path)


            self.btn_play["state"] = NORMAL
            self.btn_pause["state"] = NORMAL
            self.btn_stop["state"] = NORMAL

    def play_song(self):
        pygame.mixer.music.play()
        self.isPlaying = True


        self.btn_play["state"] = DISABLED

    def pause_song(self):
        if self.isPlaying:
            pygame.mixer.music.pause()
            self.isPlaying = False
            self.btn_play["state"] = NORMAL

    def stop_song(self):
        pygame.mixer.music.stop()
        self.isPlaying = False
        self.btn_play["state"] = NORMAL


        self.current_song_label["text"] = "No song selected"


root = Tk()
music_player = MusicPlayer(root)
root.mainloop()


